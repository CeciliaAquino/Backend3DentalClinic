package com.dh.clase33.service;

import com.dh.clase33.dto.TurnoDTO;
import com.dh.clase33.entity.Domicilio;
import com.dh.clase33.entity.Odontologo;
import com.dh.clase33.entity.Paciente;
import com.dh.clase33.entity.Turno;
import org.assertj.core.api.Assert;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)

@SpringBootTest


public class TurnoServiceTest {
    @Autowired
    private PacienteService pacienteService;
    @Autowired
    private OdontologoService odontologoService;
    @Autowired
    private TurnoService turnoService;

    Odontologo odontologoAGuardar = new Odontologo(4, "Yanina", "Silveira");
    Odontologo odontologo2AGuardar = new Odontologo(5, "Lucas", "Herrera");
    Paciente pacienteAGuardar = new Paciente("Olivia", "Pereira", "123456", LocalDate.of(2022, 1, 1),  new Domicilio("Calle 7", 3322, "Mdeo", "Mdeo"), "hola2233@gmail.com");

    @Test
    @Order(1)
    public void registrarTurnoTest(){

        odontologoService.guardarOdontologo(odontologoAGuardar);
        pacienteService.guardarPaciente(pacienteAGuardar);
        TurnoDTO turnoDTOAGuardar = new TurnoDTO();
        turnoDTOAGuardar.setId(1L);
        turnoDTOAGuardar.setFecha(LocalDate.of(2022, 6,3));
        turnoDTOAGuardar.setOdontologoId(odontologoAGuardar.getId());
        turnoDTOAGuardar.setPacienteId(pacienteAGuardar.getId());
        TurnoDTO turnoDTOGuardado = turnoService.guardarTurno(turnoDTOAGuardar);
        Assertions.assertEquals(1L, turnoDTOGuardado.getId());

    }

    @Test
    @Order(2)
    public void buscarTurnoIdTest() {

        Long idABuscar=1L;
        Optional<TurnoDTO> turnoBuscado = turnoService.buscarTurno(idABuscar);
        assertNotNull(turnoBuscado.get());
    }

    @Test
    @Order(3)
    public void buscarTurnoTest(){
        List<TurnoDTO> turnosDTO = turnoService.buscarTodosTurnos();
        Integer cantidadEsperada=1;
        assertEquals(cantidadEsperada,turnosDTO.size());
    }

    @Test
    @Order(4)
    public void actualizarTurnoTest(){
        odontologoService.guardarOdontologo(odontologo2AGuardar);
        pacienteService.guardarPaciente(pacienteAGuardar);
        TurnoDTO turnoDTOAGuardar = new TurnoDTO();
        turnoDTOAGuardar.setFecha(LocalDate.of(2022, 6,3));
        turnoDTOAGuardar.setOdontologoId(odontologo2AGuardar.getId());
        turnoDTOAGuardar.setPacienteId(pacienteAGuardar.getId());
        TurnoDTO turnoDTOGuardado = turnoService.guardarTurno(turnoDTOAGuardar);
        Assertions.assertEquals(5L, turnoDTOGuardado.getOdontologoId());
    }

    @Test
    @Order(5)
    public void eliminarTurnoTest() {

        Long idAEliminar=1L;
        turnoService.eliminarTurno(idAEliminar);
        Optional<TurnoDTO> turnoDTOEliminado=turnoService.buscarTurno(idAEliminar);
        assertFalse(turnoDTOEliminado.isPresent());

    }
}


