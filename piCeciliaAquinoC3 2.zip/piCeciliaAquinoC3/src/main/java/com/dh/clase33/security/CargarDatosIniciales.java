package com.dh.clase33.security;

import com.dh.clase33.entity.Paciente;
import com.dh.clase33.entity.Odontologo;
import com.dh.clase33.entity.Usuario;
import com.dh.clase33.entity.UsuarioRole;
import com.dh.clase33.entity.Domicilio;
import com.dh.clase33.repository.UsuarioRepository;
import com.dh.clase33.repository.PacienteRepository;
import com.dh.clase33.repository.OdontologoRepository;
import com.dh.clase33.repository.DomicilioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

@Component
public class CargarDatosIniciales implements ApplicationRunner {
    private final UsuarioRepository usuarioRepository;
    private final PacienteRepository pacienteRepository;
    private final OdontologoRepository odontologoRepository;

    @Autowired
    public CargarDatosIniciales(UsuarioRepository usuarioRepository,PacienteRepository pacienteRepository, OdontologoRepository odontologoRepository) {
        this.usuarioRepository = usuarioRepository;
        this.pacienteRepository = pacienteRepository;
        this.odontologoRepository = odontologoRepository;

    }

    @Override
    public void run(ApplicationArguments args) throws Exception {
        //cargar un usuario para probar
        BCryptPasswordEncoder cifrador= new BCryptPasswordEncoder();
        String passCifrada=cifrador.encode("digital");

        Usuario usuario=new Usuario("Rodolfo","Rodolfo","rebaspineiro@gmail.com",
                passCifrada, UsuarioRole.ROLE_USER);
        usuarioRepository.save(usuario);

        usuario=new Usuario("Natalia","Natalia","natalia@gmail.com",
                passCifrada, UsuarioRole.ROLE_ADMIN);
        usuarioRepository.save(usuario);

        //cargar un par de domicilios de pacientes para probar
        Domicilio domicilio1 = new Domicilio ("Calle A", 22, "Flores", "Flores");
        Domicilio domicilio2 = new Domicilio ("Calle 7", 701, "Montevideo", "Montevideo");
        Domicilio domicilio3 = new Domicilio ("Calle 40", 700, "Montevideo", "Montevideo");



        //cargar un par de pacientes para probar
        LocalDate date = LocalDate.now();
        LocalDate date2 = LocalDate.of(2018, 10, 30);
        LocalDate date3 = LocalDate.parse("2018-10-30");
        Paciente paciente1 = new Paciente("Juana", "Lopez", "33456", date, domicilio1, "analopez@gmail.com");
        pacienteRepository.save(paciente1);

        Paciente paciente2 = new Paciente("Analia", "Diaz", "33457", date2, domicilio2, "analia22@gmail.com");
        pacienteRepository.save(paciente2);

        Paciente paciente3 = new Paciente("Fernando", "Gimenez", "33459", date3, domicilio3, "fernando2622@gmail.com");
        pacienteRepository.save(paciente3);


        //cargar un par de odontologos para probar
        Odontologo odontologo1 = new Odontologo(1,"Diego","Gutierrez");
        odontologoRepository.save(odontologo1);
        Odontologo odontologo2 = new Odontologo(2,"Omar","Herrera");
        odontologoRepository.save(odontologo2);
        Odontologo odontologo3 = new Odontologo(3,"Emiliano","Eguis");
        odontologoRepository.save(odontologo3);
    }
}


