package com.dh.clase33;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clase33Application {

	public static void main(String[] args) {
		SpringApplication.run(Clase33Application.class, args);
	}

}
//CECILIA AQUINO - CAMADA 3 - DH
