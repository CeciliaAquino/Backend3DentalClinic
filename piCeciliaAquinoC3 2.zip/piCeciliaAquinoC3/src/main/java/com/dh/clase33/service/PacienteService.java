package com.dh.clase33.service;

import com.dh.clase33.entity.Paciente;
import com.dh.clase33.repository.PacienteRepository;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PacienteService {
    private PacienteRepository pacienteRepository;
    private static final Logger LOGGER=Logger.getLogger(PacienteService.class);
    @Autowired
    public PacienteService(PacienteRepository pacienteRepository) {
        this.pacienteRepository = pacienteRepository;
    }
    public Paciente guardarPaciente (Paciente paciente){
        LOGGER.info("Se inició el guardado del paciente con apellido" + paciente.getApellido());
        return pacienteRepository.save(paciente);
    }

    public void actualizarPaciente(Paciente paciente){
        LOGGER.info("Se inició una operación de actualización del paciente con id"+ paciente.getId());
        pacienteRepository.save(paciente);
    }
    public Optional<Paciente> buscarPaciente(Long id){

        LOGGER.info("Se inició una operación de búsqueda de paciente por id");
        return pacienteRepository.findById(id);
    }
    public List<Paciente> buscarTodosPacientes(){
        LOGGER.info("Se inició una operación de listado de todos los paciente");

        return pacienteRepository.findAll();
    }
    public Optional<Paciente> buscarPacienteByEmail(String email){
        LOGGER.info("Se inició una operación de búsqueda de paciente por email");
        return pacienteRepository.findByEmail(email);
    }
    public void eliminarPaciente(Long id){
        LOGGER.warn("Se inició una operación de eliminación del paciente con id"+ id);
        pacienteRepository.deleteById(id);
    }
}

