package com.dh.clase33.repository;
import com.dh.clase33.entity.Turno;
import org.springframework.data.jpa.repository.JpaRepository;


public interface TurnoRepository extends JpaRepository<Turno,Long> {
}

