package com.dh.clase33.service;

import com.dh.clase33.entity.Odontologo;
import com.dh.clase33.repository.OdontologoRepository;
import com.dh.clase33.exception.ResourceNotFoundException;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OdontologoService {
    private OdontologoRepository odontologoRepository;

    private static final Logger LOGGER=Logger.getLogger(OdontologoService.class);
    @Autowired
    public OdontologoService(OdontologoRepository repository) {this.odontologoRepository = repository;
    }

    public Odontologo guardarOdontologo(Odontologo odontologo) {
        LOGGER.info("Se inició el guardado de odontólogo con apellido" + odontologo.getApellido());
        return odontologoRepository.save(odontologo);
    }
    public void actualizarOdontologo(Odontologo odontologo) {
        LOGGER.info("Se inició una operación de actualización del odontólogo con id"+ odontologo.getId());
        odontologoRepository.save(odontologo);
    }
    public void eliminarOdontologo(Long id) throws ResourceNotFoundException {
        //el se va a encargar de emitir la exception
        Optional<Odontologo> odontologoAEliminar=buscarOdontologoById(id);
        if (odontologoAEliminar.isPresent()){
            odontologoRepository.deleteById(id);
            LOGGER.warn("Se inició una operación de eliminación del odontólogo con id"+ id);
        }
        else{
            throw new ResourceNotFoundException("El odontólogo a eliminar no existe" +
                    " en la base de datos, se intentó encontrar sin éxito en id= "+id);
        }

    }
    public Optional<Odontologo> buscarOdontologoById(Long id) {
        LOGGER.info("Se inició una operación de búsqueda de odontólogo");
        return odontologoRepository.findById(id);
    }
    public List<Odontologo> buscarTodosOdontologos(){
        LOGGER.info("Se inició una operación de listado de odontólogo");
        return odontologoRepository.findAll();
    }
}
