package com.dh.clase33.contoller;

import com.dh.clase33.entity.Odontologo;
import com.dh.clase33.service.OdontologoService;
import com.dh.clase33.service.TurnoService;
import com.dh.clase33.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/odontologos")
public class OdontologoController {

    @Autowired
    private final OdontologoService serviceOdontologo;
    private final TurnoService serviceTurno;
    public OdontologoController(OdontologoService odontologoService, TurnoService serviceTurno) {
        this.serviceOdontologo = odontologoService;
        this.serviceTurno = serviceTurno;
    }

    @GetMapping
    public ResponseEntity<List<Odontologo>> buscarTodosOdontologos(){
        return ResponseEntity.ok(serviceOdontologo.buscarTodosOdontologos());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Odontologo> buscarPorId(@PathVariable Long id) {
        Optional<Odontologo> odontologoBuscado = serviceOdontologo.buscarOdontologoById(id);
        if (odontologoBuscado.isPresent()) {
            return ResponseEntity.ok(odontologoBuscado.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    public ResponseEntity<Odontologo> crearOdontologo(@RequestBody Odontologo odontologo) {
        Odontologo odontologoCreado = serviceOdontologo.guardarOdontologo(odontologo);
        if (odontologoCreado.getId() != null) {
            return ResponseEntity.status(HttpStatus.CREATED).body(odontologoCreado);
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }

    @DeleteMapping("/id")
    public ResponseEntity<String> eliminarOdontologo(@PathVariable Long id) throws ResourceNotFoundException {
        serviceOdontologo.eliminarOdontologo(id);
        return ResponseEntity.ok("Se eliminó al odontologo con id= "+id);
    }

    @PutMapping
    public ResponseEntity<String> actualizarOdontologo(@RequestBody Odontologo odontologo){
        Optional<Odontologo> odontologoBuscado=serviceOdontologo.buscarOdontologoById(odontologo.getId());
        if (odontologoBuscado.isPresent()){
            serviceOdontologo.actualizarOdontologo(odontologo);
            return ResponseEntity.ok("Se actulizó el paciente con " +
                    "apellido "+odontologo.getApellido());
        }
        else{
            return ResponseEntity.badRequest().body("El odontologo con id= "+
                    odontologo.getId()+" no existe en la BD." +
                    "No se puede actualizar un odontologo que no existe en la base de datos");
        }
    }
}
