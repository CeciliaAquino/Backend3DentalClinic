package com.dh.clase33.entity;

public enum UsuarioRole {
    ROLE_ADMIN, ROLE_USER
}
