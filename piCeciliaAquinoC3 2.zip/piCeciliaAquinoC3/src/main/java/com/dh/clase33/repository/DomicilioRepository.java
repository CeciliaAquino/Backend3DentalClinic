package com.dh.clase33.repository;

public interface DomicilioRepository {
}
